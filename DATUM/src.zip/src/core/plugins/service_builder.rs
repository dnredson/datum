use anyhow::Result;
use serde_json::{json, Value as JsonValue};

use crate::core::ids;
use crate::core::model::{Edge, Entity, Event, Snapshot};
use crate::core::plugin::Plugin;

pub struct ServiceBuilderPlugin;

impl ServiceBuilderPlugin {
    pub fn new() -> Self {
        Self
    }
}

/// Normaliza nomes para matching cross-platform.
/// - trim + lowercase
/// - remove aspas
/// - remove caminho ("/usr/bin/sshd" -> "sshd", "C:\x\datum.exe" -> "datum.exe")
/// - remove extensão .exe (pra facilitar "datum" == "datum.exe")
fn norm_key(raw: &str) -> String {
    let mut s = raw
        .trim()
        .trim_matches('"')
        .trim_matches('\'')
        .to_lowercase();

    // remove caminho (linux)
    if let Some(pos) = s.rfind('/') {
        s = s[pos + 1..].to_string();
    }
    // remove caminho (windows)
    if let Some(pos) = s.rfind('\\') {
        s = s[pos + 1..].to_string();
    }

    // remove .exe para matching mais flexível
    if let Some(stripped) = s.strip_suffix(".exe") {
        s = stripped.to_string();
    }

    s
}

/// Extrai possíveis "nomes" de um container, para matching.
fn container_name_candidates(attrs: &JsonValue) -> Vec<String> {
    let mut out = Vec::new();

    // comum: attrs["name"] = "teste-monitoramento"
    if let Some(s) = attrs.get("name").and_then(|v| v.as_str()) {
        // alguns collectors podem guardar múltiplos nomes "a,b"
        for part in s.split(',') {
            let k = norm_key(part);
            if !k.is_empty() {
                out.push(k);
            }
        }
    }

    // formatos alternativos / futuros
    if let Some(s) = attrs.get("container_name").and_then(|v| v.as_str()) {
        let k = norm_key(s);
        if !k.is_empty() {
            out.push(k);
        }
    }
    if let Some(arr) = attrs.get("names").and_then(|v| v.as_array()) {
        for v in arr {
            if let Some(s) = v.as_str() {
                let k = norm_key(s);
                if !k.is_empty() {
                    out.push(k);
                }
            }
        }
    }

    out
}

/// Extrai possíveis "nomes" de um process-group, para matching.
/// No teu snapshot Windows: attrs["image_name"] (ex.: "datum.exe").
fn process_name_candidates(attrs: &JsonValue) -> Vec<String> {
    let mut out = Vec::new();
    let keys = [
        "name",
        "image_name",     // windows tasklist consolidado
        "comm",           // linux (ps/comm)
        "exe",
        "binary",
        "process_name",
    ];

    for k in keys {
        if let Some(s) = attrs.get(k).and_then(|v| v.as_str()) {
            let n = norm_key(s);
            if !n.is_empty() {
                out.push(n);
            }
        }
    }

    out
}

fn find_container_by_name(snapshot: &Snapshot, wanted: &str) -> Option<String> {
    let wanted = norm_key(wanted);

    for e in snapshot.entities.iter() {
        if e.kind != "container" {
            continue;
        }
        let candidates = container_name_candidates(&e.attrs);
        if candidates.iter().any(|c| c == &wanted) {
            return Some(e.id.clone());
        }
    }
    None
}

fn find_process_group_by_name(snapshot: &Snapshot, wanted: &str) -> Option<String> {
    let wanted = norm_key(wanted);

    for e in snapshot.entities.iter() {
        if e.kind != "process" {
            continue;
        }
        let candidates = process_name_candidates(&e.attrs);
        if candidates.iter().any(|c| c == &wanted) {
            return Some(e.id.clone());
        }
    }
    None
}

fn mk_event_id(cycle_id: &str, service_id: &str) -> String {
    // determinístico por ciclo + service
    let c = ids::sanitize_id_component(cycle_id);
    let s = ids::sanitize_id_component(service_id);
    format!("event:service_unbound:{}:{}", s, c)
}

impl Plugin for ServiceBuilderPlugin {
    fn name(&self) -> &'static str {
        "service_builder"
    }

    fn apply(&self, snapshot: &mut Snapshot, cfg: &crate::config::Config) -> Result<()> {
        let scfg = match cfg.services.as_ref() {
            Some(s) if s.enabled => s,
            _ => return Ok(()),
        };

        let observed_at = snapshot.meta.observed_at_utc;
        let cycle_id = snapshot.meta.cycle_id.clone();

        for item in scfg.items.iter() {
            let service_eid = ids::service_id(&item.name);

            // bindings resolvidos (podem ser 0..N)
            let mut bindings_json: Vec<JsonValue> = Vec::new();
            let mut edges_to_push: Vec<Edge> = Vec::new();

            // Se você ainda estiver com implemented_by singular (fase anterior),
            // basta manter item.implemented_by como Vec no config (ver nota abaixo).
            for impl_ in item.implemented_by.iter() {
                // prioridade dentro do binding: container_name > process_name
                if let Some(ref cname) = impl_.container_name {
                    if let Some(cid) = find_container_by_name(snapshot, cname) {
                        bindings_json.push(json!({
                            "bound": true,
                            "target_id": cid,
                            "target_kind": "container",
                            "via": "container_name",
                            "wanted": cname
                        }));
                        // edge
                        let to_id = bindings_json
                            .last()
                            .and_then(|b| b.get("target_id"))
                            .and_then(|v| v.as_str())
                            .unwrap()
                            .to_string();

                        edges_to_push.push(Edge {
                            from: service_eid.clone(),
                            to: to_id,
                            rel: "implemented_by".to_string(),
                            attrs: json!({ "via": "container_name" }),
                            observed_at_utc: observed_at,
                        });
                        continue;
                    } else {
                        // binding declarado mas não encontrado
                        bindings_json.push(json!({
                            "bound": false,
                            "target_id": null,
                            "target_kind": "container",
                            "via": "container_name",
                            "wanted": cname
                        }));
                        continue;
                    }
                }

                if let Some(ref pname) = impl_.process_name {
                    if let Some(pid) = find_process_group_by_name(snapshot, pname) {
                        bindings_json.push(json!({
                            "bound": true,
                            "target_id": pid,
                            "target_kind": "process",
                            "via": "process_name",
                            "wanted": pname
                        }));

                        let to_id = bindings_json
                            .last()
                            .and_then(|b| b.get("target_id"))
                            .and_then(|v| v.as_str())
                            .unwrap()
                            .to_string();

                        edges_to_push.push(Edge {
                            from: service_eid.clone(),
                            to: to_id,
                            rel: "implemented_by".to_string(),
                            attrs: json!({ "via": "process_name" }),
                            observed_at_utc: observed_at,
                        });
                    } else {
                        bindings_json.push(json!({
                            "bound": false,
                            "target_id": null,
                            "target_kind": "process",
                            "via": "process_name",
                            "wanted": pname
                        }));
                    }
                }
            }

            let bound_any = bindings_json
                .iter()
                .any(|b| b.get("bound").and_then(|v| v.as_bool()) == Some(true));

            // entidade service
            let ent = Entity {
                id: service_eid.clone(),
                kind: "service".to_string(),
                attrs: json!({
                    "name": item.name,
                    "status": "unknown",       // Fase 2.1 ainda não roda check
                    "desired_state": "running",
                    "binding": {
                        "bound": bound_any
                    },
                    "bindings": bindings_json
                }),
                observed_at_utc: observed_at,
                ttl_s: 60,
            };

            snapshot.entities.push(ent);

            // edges (um por binding resolvido)
            for e in edges_to_push {
                snapshot.edges.push(e);
            }

            // evento informativo quando nenhum binding foi resolvido
            if !bound_any {
                snapshot.events.push(Event {
                    id: mk_event_id(&cycle_id, &service_eid),
                    kind: "service_unbound".to_string(),
                    severity: "info".to_string(),
                    target: service_eid.clone(),
                    message: format!(
                        "Service '{}' has no resolved bindings (check implemented_by in config)",
                        item.name
                    ),
                    observed_at_utc: observed_at,
                });
            }
        }

        Ok(())
    }
}